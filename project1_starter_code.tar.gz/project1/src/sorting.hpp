// ICS 46 Summer 2015
// Project 1
//
// This file contains your implementations of the sorting algorithms. Do not
// change the function headers, as the functions in reporting.hpp will be
// calling these functions.
//
#ifndef __SORTING_HPP__
#define __SORTING_HPP__
#include <vector>

// =============================================================================
// Helper functions
// =============================================================================

// Swaps two values
template <typename T>
void swap(T& a, T& b)
{
    T temp = a;
    a = b;
    b = temp;
}

// Checks if a vector is sorted
template <typename T>
bool is_sorted(const std::vector<T>& vector)
{
    auto t = vector[0];
    for (auto e : vector)
    {
        if (e < t) return false;
        t = e;
    }
    return true;
}

//Print a vector
template <typename T>
void print_vector(const std::vector<T>& vector)
{
    for (T e : vector)
       std::cout << e << " ";
    std::cout << std::endl;
}

// =============================================================================
// Sorting functions
// =============================================================================

// Your insertion sort implementation
template <typename T>
void insertion_sort(std::vector<T>& vector)
{
    //TODO: implement insertion sort
}

// Your merge sort implementation
template <typename T>
void merge_sort(std::vector<T>& vector)
{
    //TODO: implement merge sort
}

// Your hybrid sort implementation
template <typename T>
void hybrid_sort(std::vector<T>& vector)
{
    //TODO: implement the hybrid sort described in the project description
}

#endif // __SORTING_HPP__
